package com.myblog9.service;

public class MainUtil {
    // i thought no need sir created this class for giving example purpose
}
